import React, { Component } from 'react';
import "./Home.css";
import Popup from "../Popup/Popup";

class Home extends Component {
    constructor(props) {
        super(props);
        this.state = {
            showePopup: false
        }
    }
    handleShowPopup = () => {
        this.setState({ showePopup: true })
    }
    handleHidePopup=()=>{
        this.setState({ showePopup: false })
    }
    render() {
        return (
            <React.Fragment>
                <div className="prj_main_container">
                    <div>
                        <div className="name_header">
                            <div className="heading heading_width">TRIPWIZ</div>
                            <div className="content_header">
                                <div>Experiences</div>
                                <div>Questions</div>
                                <button className="signin_btn btn">SIGN IN</button>
                            </div>
                        </div>
                        <div className="middle_content">
                            <div className="lrg_title">
                                DISCOVER NEW ADVENTURES
                            <div className="underline"></div>
                            </div>
                            <div className="width_2"></div>
                            <div className="paragraphs">
                                <div>
                                    We offer you a totally flexible and personal service so you can experience Kerala and Tamil Nadu your way. Take a glimpse at the tours we offer- for you to get inspired.
                            </div>
                                <br />
                                <div>
                                    All of our sample tours can be customized to suit your personal preferences, Or, you can request your own personal tour.
                            </div>
                            </div>
                        </div>
                        <div className="img_text_container">
                            <img src="/images/image.png" alt="" className="book_container" />
                            <div className="width_4"></div>
                            <div className="book_container">
                                <div className="heading">HERE WE GO</div>
                                <div className="text">
                                    We'll design a complete itinerary for you. From suggesting our favourite places that we are sure you'd love and the sights you shouldn't miss, we are at your service, throughout. We'll book your accomodation and transport, and happy to drive you anywhere you want.
                            </div>
                                <button className="trip_btn btn" onClick={this.handleShowPopup}>CUSTOMIZE MY TRIP</button>
                            </div>
                        </div>
                        <div className="footer_container">
                            <div className="footer_text">Copyright &copy; 2010-2017 Tripwiz.</div>
                        </div>
                    </div>
                    {this.state.showePopup?<div id="popdiv" className="shadow"><Popup hideFunction={this.handleHidePopup}/></div>:(null)}
                </div>
            </React.Fragment>
        )
    }
}
export default Home;