import React, { Component } from 'react';
import "./Popup.css"

class Popup extends Component {
    constructor(props) {
        super(props);
        this.state = {
            displayMenu: false,
            displayMenudest: false,
            statesList:["Kerala","Tamil Nadu"],
            districtList:[],
            name:"",
            email:"",
            phone:"",
            states:"Select your state",
            destination:"Destinations",
        }
        this.isValidForm=false;
        this.showDropdownMenu = this.showDropdownMenu.bind(this);
        this.hideDropdownMenu = this.hideDropdownMenu.bind(this);
    }
    showDropdownMenu(event, check) {
        event.preventDefault();
        if (check === "dest") {
            this.setState({ displayMenudest: true }, () => {
                document.addEventListener('click', this.hideDropdownMenu);
            });
        }
        else {
            this.setState({ displayMenu: true }, () => {
                document.addEventListener('click', this.hideDropdownMenu);
            });
        }
    }

    hideDropdownMenu() {
        this.setState({ displayMenu: false, displayMenudest: false }, () => {
            document.removeEventListener('click', this.hideDropdownMenu);
        });

    }
    close = () => {
        this.props.hideFunction();
    }
    handleSubmit = (event) => {
        event.preventDefault();
        var letters = /^[a-z||A-Z][a-z||A-Z\s]*$/;
        var phoneno = /^\d{10}$/;
        if (!this.state.name.match(letters)) {
            document.getElementById("error").innerHTML = "Name must contain only letters";
            this.isValidForm=false
        }
        else if (!(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(this.state.email))) {
            document.getElementById("error").innerHTML = "Invali Email";
            this.isValidForm=false
        }
        else if(!this.state.phone.match(phoneno)){
            document.getElementById("error").innerHTML = "Enter valid Phone number"
            this.isValidForm=false
        }
        else if(this.state.states==="Select your state"){
            document.getElementById("error").innerHTML = "Select a state"
            this.isValidForm=false
        }
        else if(this.state.destination==="Destinations"){
            document.getElementById("error").innerHTML = "Select a destination"
            this.isValidForm=false
        }
        else{
            this.isValidForm=true
        }
        this.handleSet();
    }
    handleSet=()=>{
        console.log(this.isValidForm)
        if(this.isValidForm){
            alert(JSON.stringify("Dear, "+this.state.name+" you've submitted your trip to "+this.state.destination))
        }
    }
    handleChange=(event)=>{ 
        document.getElementById("error").innerHTML=""
        if(event.target.name==="name"){
            this.setState({name:event.target.value})
        }
        else if(event.target.name==="email"){
            this.setState({email:event.target.value})
        }
        else if (event.target.name === "phone") {
            this.setState({ phone: event.target.value })
            }
        }
    handlePlace=(value,check)=>{
        if(check === "states"){
            this.setState({states:value,destination:"Destinations"})
            if(value === "Kerala"){
                this.setState({districtList:["Thrissur","Kollam","Idukki","Palakkad","Ernamkulam","Thiruvananthapuram","Wayanad","Malapuram","Kozhikode","Kasargode","Alapuzha","Kottayam","Pathanamthitta"]})
            }
            else{
                this.setState({districtList:["Chennai","Erode","Coimatore","Ariyalur"]})
            }
        }
        else{
            this.setState({destination:value})
        }
    }
    render() {
        return (
            <div className="main_container">
                <div className="popup_container">
                    <div className="close_btn_container">
                        <div className="closebtn" onClick={this.close}>X</div>
                    </div>
                    <div className="forms_container">
                        <form className="class_content" onSubmit={this.handleSubmit}>
                            <div className="first_form marg_lt">
                                <div className="heading_form">ENTER YOUR DETAILS</div>
                                <input type="text" name="name" placeholder="Name" className="text_input" value={this.state.name} onChange={this.handleChange}/>
                                <input type="text" placeholder="E-mail" className="text_input" name="email" value={this.state.email} onChange={this.handleChange}/>
                                <input type="text" placeholder="Phone No" className="text_input" name="phone" value={this.state.phone} onChange={this.handleChange}/>
                            </div>
                            <div className="first_form marg_rt">
                                <div className="heading_form">SELECT YOUR DESTINATION</div>
                                <div className="dropdown">
                                    <div className="button" onClick={(event) => this.showDropdownMenu(event, "")}>{this.state.states}</div>
                                    {this.state.displayMenu ? (
                                        <ul>{this.state.statesList.map((states)=>{return(
                                        <li onClick={()=>{this.handlePlace(states,"states")}}>{states}</li>
                                        )})} 
                                        </ul>
                                    ) : (null)
                                    }
                                </div>
                                <div className="dropdown">
                                    <div className="button" onClick={(event) => this.showDropdownMenu(event, "dest")}>{this.state.destination}</div>
                                    {this.state.displayMenudest ? (
                                        <ul>
                                            {this.state.districtList.map((district)=>{return(
                                            <li onClick={()=>{this.handlePlace(district,"")}}>{district}</li>
                                            )})}
                                        </ul>
                                    ) : (null)
                                    }
                                </div>
                                <div className="btns_container">
                                    <button className="btn_sub" onClick={this.handleSubmit}>SUBMIT</button>
                                    <button className="btn_sub" onClick={this.close}>CANCEL</button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div className="error_msg" id="error"></div>
                </div>
            </div>
        )
    }
}
export default Popup;